package com.capgemini.EurekaServer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MovieCatalogEurekaServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(MovieCatalogEurekaServerApplication.class, args);
	}

}
